const mongoosedb = require('mongoose')

const testSchema = mongoosedb.Schema({
    name: {
        type : String,
        required : true
    },
    tech:{
        type: String,
        required: true
    },
    sub:{
        type: Boolean,
        required: true,
        default: false
    }
})

module.exports = mongoosedb.model('TestsSC',testSchema)