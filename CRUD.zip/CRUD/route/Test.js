const express = require('express');
const router = express.Router();
const Test = require('../models/Tests')

router.get('/', async(req,res) =>{
    try{
        const test = await Test.find();
        res.json(test)
        console.log("Hai node JS")
    }catch(err)
    {
        res.send('Error' + err)
    }
})

router.get('/:id', async(req,res) =>{
    try{
        const test = await Test.findById(req.params.id);
        res.json(test)
        console.log("Hai node JS")
    }catch(err)
    {
        res.send('Error' + err)
    }
})

router.post('/', async(req,res) =>{
    const test1 = new Test({
        name: req.body.name,
        tech: req.body.tech,
        sub: false
    })
    try{
        const t1 = await test1.save()
        res.json(t1)
    }catch(err)
    {
        res.send(err)
    }
})

router.patch('/:id', async(req,res) =>{
    try{
        const test = await Test.findById(req.params.id)
        test.sub = req.body.sub
        test.name = req.body.name
        test.tech = req.body.tech
        const a1 = await test.save()
        res.json(test)
    }catch(err)
    {
        res.send('Error' + err)
    }
})

router.delete('/:id', async(req,res) =>{
    try{
        const test = await Test.findById(req.params.id)
        const a1 = await test.remove()
        res.send("removed")
    }catch(err)
    {
        res.send('Error' + err)
    }
})


module.exports = router