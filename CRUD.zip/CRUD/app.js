const express = require('express')
const mongoosedb = require('mongoose')
const urladress = 'mongodb://localhost/TestDB'
const app = express()

mongoosedb.connect(urladress)
const con = mongoosedb.connection

con.on('open',function(){
    console.log('Connected')
})

app.use(express.json())

const testRoute = require('./route/Test')
app.use('/Test',testRoute)

app.listen(9000, function(){
    console.log('Started')
})